# Grants Manager

A local grant-management app for research faculty. Everything runs and
stays on **your** computer — no accounts, no cloud, no internet needed.
This copy starts completely empty: it contains the app only, no data.

## Before you install — the one requirement

The app needs **Python 3** (free). Check whether you already have it:

- **Mac** — open Terminal (Cmd+Space, type "Terminal") and run:

      python3 --version

  If it prints a version (3.9 or newer), you're ready. If a dialog offers
  to install "command line developer tools", accept it — that installs
  Python for you.

- **Windows** — the easiest way: just double-click **Start Grants Manager
  (Windows).bat** (below). If Python is missing it opens the **Microsoft
  Store** for you — click **Get** (no admin rights needed), wait, then
  double-click the starter again. That's it.

  Prefer to do it by hand? Open Command Prompt (Windows key, type "cmd")
  and run `py --version`. If not found, either install from the Microsoft
  Store (search "Python 3") or from <https://www.python.org/downloads/>
  (there, **check "Add python.exe to PATH"** during setup).

There is nothing else to install: the app uses only what ships with Python.

## Install & run

1. **Extract the zip to a real folder first.** On Windows, right-click
   `GrantsManager.zip` — **Extract All...**; on Mac, double-click the zip.
   Do NOT run the starter straight from inside the zip preview — Windows
   runs it from a temporary place where the app files aren't, and it fails
   with a "server.py: No such file" error. Put the extracted folder anywhere
   (Documents, OneDrive, Desktop...) and keep it together — your database
   lives inside it.
2. Start the app:
   - **Mac**: double-click **Start Grants Manager (Mac).command**.
   - **Windows**: double-click **Start Grants Manager (Windows).bat**.

   The **first time only**, your Mac or Windows will probably warn that it
   can't verify the app. That is normal for any program not sold through
   Apple's or Microsoft's store — nothing is wrong. Let it through once
   (see "If your Mac or Windows blocks it" below) and it opens normally after
   that. If you prefer the command line: Mac `python3 server.py --launch`,
   Windows `py server.py --launch`.
3. Your browser opens at <http://127.0.0.1:8765> with an **empty
   database**. Leave the terminal window open while you use the app.

## If your Mac or Windows blocks it

The app isn't code-signed with a paid Apple/Microsoft certificate, so the
system asks you to confirm the first launch. You do this **once** per
computer; it is not a real error, and it needs no administrator.

**Mac** — if you see "Apple could not verify ... is free of malware",
click Done, then open **System Settings → Privacy & Security**, scroll to
the **Security** section, and click **Open Anyway** next to the blocked
starter (confirm with your password/Touch ID). On older macOS instead
**right-click** the starter → **Open** → **Open**. Last resort: in
the **Terminal** app type `xattr -dr com.apple.quarantine ` and drag this
folder onto the window, then press Return.

**Windows** — if you see the blue "Windows protected your PC"
(SmartScreen) box, click **More info**, then **Run anyway**. If the browser
flagged the download, choose **Keep**.

## First steps

Click **+ New grant**, enter the award, then click any number in the
budget matrix to set budgets by category and year. Add expenses from the
dashboard (drop receipt PDFs/photos onto the form). Add people and
appointments to see hiring projections on the **Summary** tab. The
**Instructions** tab inside the app explains every feature.

## Workday (optional)

When the app opens it asks whether to **connect to Workday or work
offline** — everything works fully offline. Connected, it can pull your
official balances and posted charges (drop report exports into a
`workday_imports/` folder next to the app, or set up a direct RaaS
connection in the ⇅ Workday panel), and push new expenses as
workday-ready emails to your financial team through **Microsoft Outlook**
(Mac or Windows), with the receipt PDF attached and you CC'd. If Outlook can't
be controlled (the "new Outlook" or none installed), the app prepares a folder
with the files and a ready-to-send email draft instead. Monthly report receipts
are renamed like `03 - 2026-09-15 - 412.75 - Lab supplies.pdf`, matching the
Receipt column of the workbook row they belong to.

## Updating to a newer version

When a newer version exists, the app tells you (bell icon, and at the bottom
of **⚙ Settings**). Click it, then **Update now**. The app downloads the
release from this project's GitHub page, installs it over the current copy
and restarts itself. **Your data is never touched** — grants, expenses,
receipts, backups and settings stay exactly where they are. It backs up your
database first and keeps your previous version in `data/code_backups/`, so you
can go back. It works only from the computer running the app, in a folder the
app can write to; otherwise it points you to the download instead.

*By hand instead* (or when coming from a version older than 1.4.7, which
can't update itself): download the new `GrantsManager.zip`, extract it, and
copy **both** your `data` folder (database, backups, settings) **and** your
`receipts` folder from the old copy into the new one, replacing the empty
ones. Then start the new copy — it takes over from the old one on its own.

## Your data

Everything lives in this folder: `data/grants.db` (the database) and
`receipts/`.

**Automatic backups.** Each time the app starts it saves a dated copy of
your data into `data/backups/` (one per day, kept 30 days). You can also
download a copy any time from **Settings (gear icon) > Backups & data
safety**, and restore from one there if something goes wrong.

**Undo.** Deleting a grant, person, appointment or expense sends it to
**Settings > Recently deleted** for 30 days, so a mistaken delete can be
put back — restoring a grant also brings back its expenses and
appointments.

### One important warning if you keep this in OneDrive/Dropbox

Cloud sync is fine for *having* a copy elsewhere, but **never run Grants
Manager on two computers at the same time**, and wait for sync to finish
before opening it on another machine. Databases don't merge the way
documents do: if two copies are open at once, the sync service can't
combine them and will either overwrite one or leave a "conflicted copy"
file beside the real one. If you ever see such a file, don't delete it —
it may contain work missing from the main file. Check both, or restore a
backup from the Settings panel.

## Troubleshooting

- **Browser doesn't open** — start it yourself and visit
  <http://127.0.0.1:8765>.
- **`python3` / `py` not found** — install Python (see above).
- **The app shows different data than I expected** — you probably opened
  a different copy (folder) of Grants Manager. Every copy keeps its own data
  inside its own folder, and opening a copy replaces whichever copy was
  already running. Open the folder that holds your real `data` folder.
- **Stop the app** — close the terminal window.
